﻿namespace RTLTMPro
{
    public enum HinduNumbers
    {
        Zero = 0x0660,
        One = 0x0661,
        Two = 0x0662,
        Three = 0x0663,
        Four = 0x0664,
        Five = 0x0665,
        Six = 0x0666,
        Seven = 0x0667,
        Eight = 0x0668,
        Nine = 0x0669
    }
}